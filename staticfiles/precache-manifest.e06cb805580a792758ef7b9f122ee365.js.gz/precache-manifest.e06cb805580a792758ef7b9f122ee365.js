self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "980e34bfb2cefe603441186ddefe545e",
    "url": "/index.html"
  },
  {
    "revision": "0f25f7ea77bff7d0dfd9",
    "url": "/static/css/2.fa92f2e3.chunk.css"
  },
  {
    "revision": "56f86a88241dd3de2adc",
    "url": "/static/css/main.b95f8418.chunk.css"
  },
  {
    "revision": "0f25f7ea77bff7d0dfd9",
    "url": "/static/js/2.088eb24b.chunk.js"
  },
  {
    "revision": "4818b813f0dd1ba4a3bb85e4158cb9b3",
    "url": "/static/js/2.088eb24b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "56f86a88241dd3de2adc",
    "url": "/static/js/main.00ed5927.chunk.js"
  },
  {
    "revision": "2747b914e9a60db2276f",
    "url": "/static/js/runtime-main.c8a21426.js"
  },
  {
    "revision": "0adceaae2f4a96b07fb41165d5308e56",
    "url": "/static/media/Spinner.0adceaae.gif"
  }
]);